import Counter from "./feature/counter/Counter";
function App() {
  return (
    <main className="App">
      <Counter />
    </main>
  );
}

export default App;
